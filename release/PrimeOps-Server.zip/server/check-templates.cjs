const crypto = require('node:crypto');
const schema = `CREATE TABLE IF NOT EXISTS check_templates (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  questions JSONB NOT NULL,
  property_ids TEXT[] NOT NULL DEFAULT '{}',
  active BOOLEAN NOT NULL DEFAULT TRUE,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by TEXT REFERENCES app_users(id)
);`;
const types = ['yes-no', 'yes-no-na', 'pass-fail-na', 'date', 'number', 'rating', 'textarea', 'text'];
function validateTemplate(value) {
  if (!value || typeof value.title !== 'string' || !value.title.trim() || value.title.length > 150
      || !Array.isArray(value.questions) || !value.questions.length || value.questions.length > 200
      || !Array.isArray(value.propertyIds) || value.propertyIds.some((id) => typeof id !== 'string' || !id || id.length > 120)) {
    throw new Error('Enter a checklist title, building selection and 1-200 questions.');
  }
  const questions = value.questions.map((question) => {
    if (!question || typeof question.label !== 'string' || !question.label.trim() || question.label.length > 1000
        || !types.includes(question.type) || typeof question.photo !== 'boolean') throw new Error('Each question needs text, a valid answer type and a photo setting.');
    return { id: crypto.randomUUID(), label: question.label.trim(), type: question.type, photo: question.photo, required: true };
  });
  return { title: value.title.trim(), questions, propertyIds: [...new Set(value.propertyIds)] };
}
async function seed(pool) {
  for (const template of require('./check-templates.json').templates) {
    await pool.query(`INSERT INTO check_templates(id,title,questions) VALUES($1,$2,$3::jsonb) ON CONFLICT DO NOTHING`,
      [template.id, template.title, JSON.stringify(template.questions)]);
  }
}
function mount(app, { pool, authenticate, accessibleProperties, apiError }) {
  const fail = (res, error) => {
    console.error('Checklist templates failed:', error.message);
    return apiError(res, error.status || (error.code ? 503 : 400), error.code ? 'Could not save checklist. Retry.' : error.message);
  };
  async function allowed(req, ids) {
    if (!['admin', 'maintenance_manager'].includes(req.user.role)) throw Object.assign(new Error('MM or administrator access is required.'), { status: 403 });
    const properties = await accessibleProperties(req.user);
    if (!ids.length && req.user.role !== 'admin') throw Object.assign(new Error('Select your assigned buildings.'), { status: 403 });
    if (ids.some((id) => !properties.some((property) => property.id === id))) throw Object.assign(new Error('Choose buildings within your access.'), { status: 403 });
  }
  app.get('/api/check-templates', authenticate, async (req, res) => {
    try {
      const ids = (await accessibleProperties(req.user)).map((property) => property.id);
      const { rows } = await pool.query(`SELECT id,title,questions,property_ids AS "propertyIds",active FROM check_templates
        WHERE active=TRUE AND (cardinality(property_ids)=0 OR property_ids && $1::TEXT[]) ORDER BY title`, [ids]);
      return res.json({ templates: rows });
    } catch (error) { return fail(res, error); }
  });
  app.post('/api/check-templates', authenticate, async (req, res) => {
    try {
      const data = validateTemplate(req.body);
      await allowed(req, data.propertyIds);
      const id = crypto.randomUUID();
      await pool.query(`INSERT INTO check_templates(id,title,questions,property_ids,updated_by) VALUES($1,$2,$3::jsonb,$4,$5)`,
        [id, data.title, JSON.stringify(data.questions), data.propertyIds, req.user.id]);
      return res.status(201).json({ id });
    } catch (error) { return fail(res, error); }
  });
  app.put('/api/check-templates/:id/archive', authenticate, async (req, res) => {
    try {
      const { rows } = await pool.query('SELECT property_ids FROM check_templates WHERE id=$1', [req.params.id]);
      if (!rows[0]) return apiError(res, 404, 'Checklist not found.');
      await allowed(req, rows[0].property_ids);
      await pool.query('UPDATE check_templates SET active=FALSE,updated_by=$2,updated_at=NOW() WHERE id=$1', [req.params.id, req.user.id]);
      return res.json({ success: true });
    } catch (error) { return fail(res, error); }
  });
}
module.exports = { schema, seed, mount, validateTemplate };
