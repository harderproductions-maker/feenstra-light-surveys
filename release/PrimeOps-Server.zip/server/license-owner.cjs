const crypto = require('node:crypto');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { issueToken, verifyToken } = require('./license-token.cjs');
const legacy = require('../www/legacy-identifiers.json');

const schema = `
CREATE TABLE IF NOT EXISTS licence_owner (
  id INTEGER PRIMARY KEY CHECK(id=1),
  username TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  private_key_encrypted TEXT NOT NULL,
  public_key TEXT NOT NULL,
  test_renewal_enabled BOOLEAN NOT NULL DEFAULT FALSE,
  session_version INTEGER NOT NULL DEFAULT 1,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
ALTER TABLE licence_owner ADD COLUMN IF NOT EXISTS key_version INTEGER NOT NULL DEFAULT 1;`;
const renewalSchema = `CREATE TABLE IF NOT EXISTS licence_renewal_requests (
  id UUID PRIMARY KEY,
  base_token_id TEXT NOT NULL UNIQUE,
  requested_by TEXT NOT NULL REFERENCES app_users(id),
  mode TEXT NOT NULL CHECK(mode IN ('request','test')),
  status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','declined')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  reviewed_at TIMESTAMPTZ,
  result_token TEXT
);`;

function createOwnerService({ pool, ownerPool = pool, withTransaction, secret, companies, initialiseCompany }) {
  if (!secret || Buffer.byteLength(secret) < 32) throw new Error('A strong JWT_SECRET is required for owner licensing.');
  const encryptionKey = Buffer.from(crypto.hkdfSync('sha256', secret, 'PrimeOps-owner', 'signing-key-encryption-v1', 32));
  const legacyEncryptionKey = Buffer.from(crypto.hkdfSync('sha256', secret, legacy.ownerKeySalt, 'signing-key-encryption-v1', 32));
  const ownerSecret = Buffer.from(crypto.hkdfSync('sha256', secret, 'PrimeOps-owner', 'owner-session-v1', 32));
  const encrypt = (text) => {
    const iv = crypto.randomBytes(12);
    const cipher = crypto.createCipheriv('aes-256-gcm', encryptionKey, iv);
    const data = Buffer.concat([cipher.update(text, 'utf8'), cipher.final()]);
    return [iv, cipher.getAuthTag(), data].map((part) => part.toString('base64url')).join('.');
  };
  const decrypt = (text, version) => {
    const [iv, tag, data] = text.split('.').map((part) => Buffer.from(part, 'base64url'));
    const cipher = crypto.createDecipheriv('aes-256-gcm', version === 1 ? legacyEncryptionKey : encryptionKey, iv);
    cipher.setAuthTag(tag);
    return Buffer.concat([cipher.update(data), cipher.final()]).toString('utf8');
  };
  const invalid = (message, status = 400) => Object.assign(new Error(message), { status });
  const username = (value) => typeof value === 'string' ? value.trim().toLowerCase() : '';
  async function administrator(email, password, database = ownerPool) {
    const { rows } = await database.query('SELECT id,password_hash FROM app_users WHERE email=$1 AND role=$2 AND active=TRUE', [username(email), 'admin']);
    if (!rows[0] || typeof password !== 'string' || password.length > 200 || !await bcrypt.compare(password, rows[0].password_hash)) {
      throw invalid('Administrator sign-in is incorrect.', 401);
    }
    return rows[0].id;
  }
  async function manager(email, password) {
    const { rows } = await pool.query(`SELECT id,password_hash FROM app_users
      WHERE email=$1 AND role IN ('admin','maintenance_manager') AND active=TRUE`, [username(email)]);
    if (!rows[0] || typeof password !== 'string' || password.length > 200 || !await bcrypt.compare(password, rows[0].password_hash)) {
      throw invalid('Use an active MM or administrator account.', 401);
    }
    return rows[0].id;
  }
  async function lockSystem(client) {
    const { rows } = await client.query('SELECT * FROM system_licence WHERE id=1 FOR UPDATE');
    const system = rows[0];
    if (!system) throw invalid('Licence setup is unavailable.', 503);
    if (Date.now() + 300000 < new Date(system.last_seen).getTime()) throw invalid('Correct the server date/time first.', 423);
    return system;
  }
  function baseId(system, owner) {
    return system.token ? verifyToken(system.token, owner.public_key).id : 'first-activation';
  }
  function requireBase(system, owner, expected) {
    if (expected !== baseId(system, owner)) throw invalid('The licence changed. Refresh and retry.', 409);
  }
  async function issue(client, system, owner, expected, requestId = null) {
    requireBase(system, owner, expected);
    if (requestId) {
      const { rows } = await client.query("SELECT id FROM licence_renewal_requests WHERE id=$1 AND base_token_id=$2 AND status='pending' FOR UPDATE", [requestId, expected]);
      if (!rows[0]) throw invalid('This request is no longer pending. Refresh.', 409);
    }
    const token = issueToken(crypto.createPrivateKey(decrypt(owner.private_key_encrypted, owner.key_version)), system.system_id, system.token);
    await client.query('UPDATE system_licence SET token=$1,last_seen=GREATEST(last_seen,NOW()) WHERE id=1', [token]);
    await client.query(`UPDATE licence_renewal_requests SET status='approved',reviewed_at=NOW(),result_token=$2
      WHERE base_token_id=$1 AND status='pending'`, [expected, token]);
    return token;
  }
  const attempts = new Map();
  function rateLimit(req, res, next) {
    const key = `${req.ip}:${req.path}`;
    const now = Date.now();
    if (attempts.size > 10000) for (const [id, value] of attempts) if (now - value.since >= 60000) attempts.delete(id);
    let bucket = attempts.get(key);
    if (!bucket || now - bucket.since >= 60000) { bucket = { since: now, count: 0 }; attempts.set(key, bucket); }
    if (++bucket.count > 10) return res.status(429).json({ error: 'Wait a minute and retry.' });
    return next();
  }
  function route(action) {
    return async (req, res) => {
      res.set('Cache-Control', 'no-store');
      try { await action(req, res); }
      catch (error) {
        console.error('Owner licensing failed:', error.message);
        res.status(error.status || 503).json({ error: error.status ? error.message : 'Licence service unavailable. Retry.' });
      }
    };
  }
  async function authenticateOwner(req, res, next) {
    res.set('Cache-Control', 'no-store');
    try {
      const header = req.get('authorization') || '';
      if (!header.startsWith('Bearer ')) throw invalid('Sign in to the owner app.', 401);
      let claims;
      try { claims = jwt.verify(header.slice(7), ownerSecret, { issuer: 'primeops-licence-owner', algorithms: ['HS256'] }); }
      catch { throw invalid('Owner sign-in expired. Sign in again.', 401); }
      const { rows } = await ownerPool.query('SELECT * FROM licence_owner WHERE id=1');
      if (!rows[0] || claims.sub !== 'owner' || claims.version !== rows[0].session_version) throw invalid('Sign in to the owner app.', 401);
      req.licenceOwner = rows[0];
      next();
    } catch (error) {
      if (!error.status) console.error('Owner session verification failed:', error.message);
      res.status(error.status || 503).json({ error: error.status ? error.message : 'Could not verify owner sign-in.' });
    }
  }
  function mount(app, snapshot) {
    require('./subscriptions.cjs').mountOwner(app, { pool, withTransaction, authenticateOwner, route });
    require('./company-features.cjs').mountOwner(app, { pool, withTransaction, authenticateOwner, route });
    require('./owner-content.cjs').mountOwnerContent(app, { pool, authenticateOwner, route });
    app.get('/api/license/owner/setup', route(async (_req, res) => {
      const { rows } = await ownerPool.query('SELECT EXISTS(SELECT 1 FROM licence_owner) AS registered');
      res.json({ registered: rows[0].registered });
    }));
    app.post('/api/license/owner/register', rateLimit, route(async (req, res) => {
      const { adminUsername, adminPassword, ownerUsername, ownerPassword } = req.body || {};
      const name = username(ownerUsername);
      if (!name || name.length > 100 || typeof ownerPassword !== 'string' || ownerPassword.length < 12 || Buffer.byteLength(ownerPassword) > 72) {
        throw invalid('Choose an owner username and a password of 12-72 bytes.');
      }
      await administrator(adminUsername, adminPassword);
      const passwordHash = await bcrypt.hash(ownerPassword, 12);
      const keys = crypto.generateKeyPairSync('ec', { namedCurve: 'prime256v1',
        privateKeyEncoding: { type: 'pkcs8', format: 'pem' }, publicKeyEncoding: { type: 'spki', format: 'pem' } });
      const client = await ownerPool.connect();
      try {
        await client.query('BEGIN');
        await client.query('SELECT pg_advisory_xact_lock(7204102)');
        const { rows } = await client.query('SELECT id FROM licence_owner WHERE id=1');
        if (rows[0]) throw invalid('Owner already registered. Sign in.', 409);
        const { rows: systems } = await client.query('SELECT token FROM system_licence WHERE id=1 FOR UPDATE');
        if (systems[0]?.token) throw invalid('An existing file-signed licence is active. Keep its original key; migrate it before registering a new owner key.', 409);
        await administrator(adminUsername, adminPassword, client);
        await client.query(`INSERT INTO licence_owner(id,username,password_hash,private_key_encrypted,public_key,key_version)
          VALUES(1,$1,$2,$3,$4,2)`, [name, passwordHash, encrypt(keys.privateKey), keys.publicKey]);
        await client.query('COMMIT');
      } catch (error) {
        await client.query('ROLLBACK');
        throw error;
      } finally { client.release(); }
      res.status(201).json({ registered: true });
    }));
    app.post('/api/license/owner/login', rateLimit, route(async (req, res) => {
      const { rows } = await ownerPool.query('SELECT * FROM licence_owner WHERE id=1');
      const owner = rows[0];
      const password = req.body?.password;
      if (!owner || username(req.body?.username) !== owner.username || typeof password !== 'string'
          || Buffer.byteLength(password) > 72 || !await bcrypt.compare(password, owner.password_hash)) throw invalid('Owner username or password is incorrect.', 401);
      res.json({ token: jwt.sign({ version: owner.session_version }, ownerSecret,
        { subject: 'owner', issuer: 'primeops-licence-owner', expiresIn: '2h', algorithm: 'HS256' }) });
    }));
    app.get('/api/license/owner/dashboard', authenticateOwner, route(async (req, res) => {
      const { rows } = await pool.query(`SELECT r.id,r.base_token_id,r.mode,r.status,r.created_at,r.reviewed_at,
        u.display_name AS requested_by FROM licence_renewal_requests r JOIN app_users u ON u.id=r.requested_by
        ORDER BY r.created_at DESC LIMIT 50`);
      const licence = await snapshot();
      res.json({ licence, testRenewalEnabled: licence.testRenewalEnabled, requests: rows,
        companies: companies ? await companies.list() : [], companyCode: companies?.current().code || '' });
    }));
    app.put('/api/license/owner/settings', authenticateOwner, route(async (req, res) => {
      if (typeof req.body?.testRenewalEnabled !== 'boolean') throw invalid('Choose whether free test renewal is enabled.');
      await withTransaction(async (client) => {
        await lockSystem(client);
        if (companies) await companies.updateTesting(req.body.testRenewalEnabled);
        else await ownerPool.query('UPDATE licence_owner SET test_renewal_enabled=$1 WHERE id=1', [req.body.testRenewalEnabled]);
      });
      res.json({ testRenewalEnabled: req.body.testRenewalEnabled });
    }));
    app.post('/api/license/owner/companies', authenticateOwner, route(async (req, res) => {
      if (!companies || !initialiseCompany) throw invalid('Company registration is unavailable.', 503);
      res.status(201).json({ company: await companies.create(req.body || {}, initialiseCompany) });
    }));
    app.post('/api/license/owner/issue', authenticateOwner, route(async (req, res) => {
      const token = await withTransaction(async (client) => {
        const system = await lockSystem(client);
        return issue(client, system, req.licenceOwner, req.body?.baseTokenId, req.body?.requestId || null);
      });
      res.json({ token, licence: await snapshot() });
    }));
    app.post('/api/license/owner/decline', authenticateOwner, route(async (req, res) => {
      if (!/^[0-9a-f-]{36}$/i.test(req.body?.requestId || '')) throw invalid('Choose a pending renewal request.');
      const { rowCount } = await pool.query(`UPDATE licence_renewal_requests SET status='declined',reviewed_at=NOW()
        WHERE id=$1 AND status='pending'`, [req.body.requestId]);
      if (!rowCount) throw invalid('Request already reviewed. Refresh.', 409);
      res.json({ success: true });
    }));
    app.post('/api/license/renew', rateLimit, route(async (req, res) => {
      const { mode, username: email, password, baseTokenId } = req.body || {};
      if (!['request', 'test'].includes(mode)) throw invalid('Choose request renewal or free test renewal.');
      const userId = await manager(email, password);
      const result = await withTransaction(async (client) => {
        const system = await lockSystem(client);
        const { rows } = await ownerPool.query('SELECT * FROM licence_owner WHERE id=1');
        const owner = rows[0];
        if (!owner) throw invalid('The owner must register the system first.', 409);
        requireBase(system, owner, baseTokenId);
        const testing = companies ? await companies.testingEnabled() : owner.test_renewal_enabled;
        if (mode === 'test' && !testing) throw invalid('Free test renewal is disabled. Request owner approval.', 403);
        const { rows: existing } = await client.query('SELECT * FROM licence_renewal_requests WHERE base_token_id=$1 FOR UPDATE', [baseTokenId]);
        let request = existing[0];
        if (request?.status === 'declined') {
          if (mode !== 'test') throw invalid('The owner declined this renewal. Contact the owner.', 409);
          await client.query("UPDATE licence_renewal_requests SET status='pending',mode='test',reviewed_at=NULL WHERE id=$1", [request.id]);
        } else if (!request) {
          const { rows: created } = await client.query(`INSERT INTO licence_renewal_requests(id,base_token_id,requested_by,mode)
            VALUES($1,$2,$3,$4) RETURNING *`, [crypto.randomUUID(), baseTokenId, userId, mode]);
          request = created[0];
        }
        if (mode === 'test') {
          await issue(client, system, owner, baseTokenId);
          return { status: 'approved', requestId: request.id };
        }
        return { status: request.status, requestId: request.id };
      });
      res.json({ ...result, licence: await snapshot() });
    }));
  }
  return { mount };
}
module.exports = { schema, renewalSchema, createOwnerService };
