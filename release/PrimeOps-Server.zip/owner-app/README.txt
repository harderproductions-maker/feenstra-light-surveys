PRIMEOPS OWNER - WINDOWS BACKEND ADMINISTRATION

1. Extract the entire ZIP.
2. Open PrimeOps Owner.exe. Windows may warn because this test build is unsigned.
3. Enter your hosted server HTTPS address and Connect.
4. First setup only: enter the server's initial administrator credentials,
   then choose a separate owner username and password (at least 12 characters).
   Registration creates and registers the signing key automatically.
5. Sign in with your new owner login.

COMPANIES
- Register company: enter company name, unique code, admin username/password.
- The new company starts blank and can request any PrimeOps feature.
- Give the company its code and admin credentials through a secure channel.
- Its users enter that company code in PrimeOps, then sign in.
- Feenstra remains FEENSTRA. Existing records stay unchanged.

LICENCES
- Choose the company, then Generate & activate annual token.
- No first token is generated automatically.
- Approve renewal requests in the Licence tab.
- You can optionally allow Free in-app test renewal for the selected company.
  It is disabled by default. Turn it off before production charging.
- There are NO payments collected in this testing version.

SUBSCRIPTIONS AND FEATURES
- Subscriptions: Basic up to 10 active users, Building Managers up to 20,
  Operations unlimited. Every active account counts, including admins.
- Choose a plan during registration, or approve company plan requests later.
- Features: company admins select 1-5 free initial features from Home.
- Approve activation in Features. Later additions show a once-off test
  admin fee of R100 per feature. No payments are collected.
- New catalogue features are offered to existing clients, not auto-activated.
- Existing client users, passwords, checklists and records are retained.

BUILDINGS AND CHECKLISTS
- Choose the company, then Buildings & checklists.
- Add buildings on their behalf.
- Create questions or import a JSON checklist; choose all company buildings
  or selected buildings and Save. Check the company label before saving.
- JSON format:
  {"title":"Monthly check","questions":[
    {"label":"Emergency lights working?","type":"yes-no-na","photo":true}
  ]}
- Types: yes-no, yes-no-na, pass-fail-na, text, textarea, number, rating, date.
- The ordinary company app also supports Excel checklist import.
- Company admins/MMs can create/import their own checklists in Building checks.

HOSTING AND BACKUPS
- This desktop app administers an already running PrimeOps backend.
  It does not install Docker, provision cloud servers, or run the backend.
- Use HTTPS for a hosted server. HTTP is allowed only on localhost for testing.
- Back up the database, server .env/JWT_SECRET and all report folders.
  The signing key is encrypted on the server; changing JWT_SECRET without
  migrating the key prevents future token generation.
- Keep your separate owner credentials private. Company admins are not owners.
- Sign out when finished. Owner login expires after two hours.
- Existing file-generator users must migrate deliberately if they have already
  activated a licence with a manually held signing key.
