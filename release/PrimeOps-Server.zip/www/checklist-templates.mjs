export function wireChecklistTemplates({ getUser, getProperties, getTemplates, getPropertyId, apiRequest, reload, escape, readSpreadsheet }) {
  const types = [['yes-no', 'Yes / No'], ['yes-no-na', 'Yes / No / N/A'], ['pass-fail-na', 'Pass / Fail / N/A'],
    ['text', 'Short text'], ['textarea', 'Long text'], ['number', 'Number'], ['rating', 'Rating 0-10'], ['date', 'Date']];
  const dialog = document.createElement('dialog');
  dialog.className = 'survey-dialog';
  dialog.id = 'checklist-template-dialog';
  document.body.append(dialog);
  const row = (question = {}) => `<div class="template-editor-question">
    <label>Question<input data-question-label value="${escape(question.label || '')}" maxlength="1000" required /></label>
    <label>Answer<select data-question-type>${types.map(([id, name]) => `<option value="${id}" ${question.type === id ? 'selected' : ''}>${name}</option>`).join('')}</select></label>
    <label class="inline-choice"><input type="checkbox" data-question-photo ${question.photo ? 'checked' : ''} /> Allow photos</label>
    <button class="button secondary" type="button" data-remove-question>Remove question</button></div>`;
  function show() {
    const user = getUser();
    if (!['admin', 'maintenance_manager'].includes(user.role)) return;
    const properties = getProperties();
    dialog.innerHTML = `<div class="dialog-heading"><h2>Checklists</h2><button class="icon-button quiet" type="button" data-close-templates aria-label="Close">×</button></div>
      <details><summary>Existing checklists (${getTemplates().length})</summary><ul class="ticket-list">${getTemplates().map((template) => `<li><strong>${escape(template.title)}</strong><button type="button" class="button secondary" data-export-template="${escape(template.id)}">Export</button>${user.role === 'admin' || (template.propertyIds?.length && template.propertyIds.every((id) => properties.some((property) => property.id === id))) ? `<button type="button" class="button secondary" data-archive-template="${escape(template.id)}">Archive</button>` : ''}</li>`).join('')}</ul></details>
      <form id="checklist-template-form" class="storage-form">
        <h3>Create / import checklist</h3>
        <label>Import JSON or Excel<input type="file" data-import-template accept=".json,.xlsx" /></label>
        <details><summary>Import format</summary><p>JSON: title and questions (label, type, photo). Excel: Question, Type, Photo columns. Select buildings below.</p></details>
        <label>Title<input name="title" maxlength="150" required /></label>
        ${user.role === 'admin' ? '<label class="inline-choice"><input type="checkbox" name="companyWide" /> All company buildings</label>' : ''}
        <fieldset><legend>Buildings</legend>${properties.map((property) => `<label class="inline-choice"><input type="checkbox" name="propertyIds" value="${escape(property.id)}" ${property.id === getPropertyId() ? 'checked' : ''} /> ${escape(property.name)}</label>`).join('')}</fieldset>
        <div data-template-questions>${row()}</div>
        <button type="button" class="button secondary" data-add-question>+ Question</button>
        <button type="submit" class="button primary">Save checklist</button>
      </form><p data-template-status role="status"></p>`;
    dialog.showModal();
  }
  function download(template) {
    const url = URL.createObjectURL(new Blob([JSON.stringify({ title: template.title, questions: template.questions }, null, 2)], { type: 'application/json' }));
    const link = document.createElement('a');
    link.href = url;
    link.download = 'checklist-template.json';
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  document.addEventListener('click', (event) => {
    if (event.target.closest('[data-manage-checklists]')) show();
  });
  dialog.addEventListener('click', async (event) => {
    if (event.target.closest('[data-close-templates]')) { dialog.close(); return; }
    if (event.target.closest('[data-add-question]')) dialog.querySelector('[data-template-questions]').insertAdjacentHTML('beforeend', row());
    if (event.target.closest('[data-remove-question]')) event.target.closest('.template-editor-question').remove();
    const exportButton = event.target.closest('[data-export-template]');
    if (exportButton) download(getTemplates().find((template) => template.id === exportButton.dataset.exportTemplate));
    const archive = event.target.closest('[data-archive-template]');
    if (archive) {
      archive.disabled = true;
      try {
        await apiRequest(`/api/check-templates/${encodeURIComponent(archive.dataset.archiveTemplate)}/archive`, { method: 'PUT', body: {} });
        await reload();
        dialog.close();
      } catch (error) { dialog.querySelector('[data-template-status]').textContent = error.message; }
      finally { archive.disabled = false; }
    }
  });
  dialog.addEventListener('change', async (event) => {
    if (!event.target.matches('[data-import-template]') || !event.target.files[0]) return;
    const file = event.target.files[0];
    try {
      if (file.size > 2 * 1024 * 1024) throw new Error('Choose a file smaller than 2 MB.');
      let data;
      if (file.name.toLowerCase().endsWith('.xlsx')) {
        const rows = await readSpreadsheet(file);
        const headers = rows.shift()?.map((value) => String(value || '').trim().toLowerCase()) || [];
        const index = headers.indexOf('question');
        if (index < 0) throw new Error('Excel needs a Question column.');
        data = { title: file.name.replace(/\.xlsx$/i, ''), questions: rows.filter((values) => values[index]).map((values) => ({
          label: String(values[index]), type: String(values[headers.indexOf('type')] || 'yes-no-na').trim().toLowerCase(),
          photo: ['true', 'yes', '1'].includes(String(values[headers.indexOf('photo')] || '').toLowerCase())
        })) };
      } else data = JSON.parse(await file.text());
      if (!data || !Array.isArray(data.questions) || !data.questions.length || data.questions.length > 200
          || data.questions.some((question) => typeof question.label !== 'string' || !types.some(([id]) => id === (question.type || 'yes-no-na')))) {
        throw new Error('Import a checklist with 1-200 questions and valid answer types.');
      }
      dialog.querySelector('[name=title]').value = String(data.title || file.name).slice(0, 150);
      dialog.querySelector('[data-template-questions]').innerHTML = data.questions.map((question) => row({ ...question, type: question.type || 'yes-no-na' })).join('');
      dialog.querySelector('[data-template-status]').textContent = 'Imported. Select buildings and save.';
    } catch (error) { dialog.querySelector('[data-template-status]').textContent = error.message || 'Import failed.'; }
    event.target.value = '';
  });
  dialog.addEventListener('submit', async (event) => {
    event.preventDefault();
    const form = event.target, button = form.querySelector('[type=submit]');
    button.disabled = true;
    try {
      const propertyIds = form.elements.companyWide?.checked ? [] : [...form.querySelectorAll('[name=propertyIds]:checked')].map((input) => input.value);
      if (!propertyIds.length && !form.elements.companyWide?.checked) throw new Error('Select at least one building.');
      const questions = [...form.querySelectorAll('.template-editor-question')].map((element) => ({
        label: element.querySelector('[data-question-label]').value,
        type: element.querySelector('[data-question-type]').value,
        photo: element.querySelector('[data-question-photo]').checked
      }));
      await apiRequest('/api/check-templates', { method: 'POST', body: { title: form.elements.title.value, propertyIds, questions } });
      await reload();
      dialog.close();
    } catch (error) { dialog.querySelector('[data-template-status]').textContent = error.message || 'Checklist save failed.'; }
    finally { button.disabled = false; }
  });
}
