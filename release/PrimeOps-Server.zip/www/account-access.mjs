export const accountSections = [
  ['tickets', 'Maintenance tickets'], ['appliances', 'Appliance reports'],
  ['billing', 'Billing'], ['users', 'User management'],
  ['lighting', 'Lighting surveys'], ['checks', 'Building checks']
];
const defaults = {
  admin: accountSections.map(([id]) => id),
  maintenance_manager: accountSections.map(([id]) => id),
  maintenance_assistant: ['tickets', 'lighting', 'checks'],
  technician: ['appliances'],
  user: ['tickets', 'billing']
};
export function sectionsFor(user) {
  if (!user) return [];
  const sections = user.role === 'maintenance_manager' && Array.isArray(user.sections)
    ? user.sections : defaults[user.role] || [];
  return Array.isArray(user.companyFeatures)
    ? sections.filter((section) => section === 'users' || user.companyFeatures.includes(section)) : sections;
}
export function canUseSection(user, section) {
  return sectionsFor(user).includes(section);
}
export function canDelegateAccounts(user) {
  return user?.role === 'admin'
    || (user?.role === 'maintenance_manager' && user.adminRights === true && canUseSection(user, 'users'));
}
export function sectionForPath(path) {
  if (/^\/api\/check-templates(\/|$)/.test(path)) return 'checks';
  if (/^\/api\/(tickets|ticket-assignees)(\/|\?|$)/.test(path)) return 'tickets';
  if (/^\/api\/(appliance-|technician-|building-quote-contacts)/.test(path)) return 'appliances';
  if (/^\/api\/billing\//.test(path)) return 'billing';
  if (/^\/api\/users(\/|$)/.test(path) || path === '/api/properties:create') return 'users';
  return null;
}
export function canManageAccountPermissions(user, account) {
  if (user?.role === 'admin') return true;
  if (!canUseSection(user, 'users') || account.id === user?.id || account.role === 'admin') return false;
  if (account.role === 'maintenance_manager' && (!canDelegateAccounts(user) || account.adminRights || account.admin_rights)) return false;
  return sectionsFor({ ...account, sections: account.sections }).every((section) => canUseSection(user, section));
}
