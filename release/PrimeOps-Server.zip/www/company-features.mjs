export function wireCompanyFeatures({ apiRequest, getUser, getContext, refreshUser, escape }) {
  const dialog = document.createElement('dialog');
  dialog.id = 'company-features-dialog';
  dialog.className = 'survey-dialog';
  document.body.append(dialog);
  let context;
  async function load() {
    const expected = context;
    const data = await apiRequest('/api/company-features');
    if (expected !== getContext()) return;
    const pending = data.requests.find((item) => item.status === 'pending');
    const admin = getUser()?.role === 'admin';
    dialog.innerHTML = `<div class="dialog-heading"><h2>Company features</h2><button class="button secondary" type="button" data-close-features>Close</button></div>
      <p>${data.setupComplete ? 'Extra features: R100 each, once-off test admin fee.' : 'Choose 1-5 features for free setup.'} Owner approval required. No payment collected.</p>
      ${pending ? `<p role="status">Awaiting approval · R${pending.feeCents / 100}</p>` : ''}
      <form data-feature-form><fieldset><legend>Available features</legend>${data.catalog.map((item) => `<label class="inline-choice">
        <input type="checkbox" name="features" value="${escape(item.id)}" ${data.enabled.includes(item.id) ? 'checked disabled' : !admin || pending ? 'disabled' : ''} />
        ${escape(item.name)}${data.enabled.includes(item.id) ? ' — Active' : ''}</label>`).join('')}</fieldset>
        <p data-feature-total></p><button class="button primary" ${!admin || pending ? 'disabled' : ''}>Request activation</button>
      </form><p data-feature-status role="status">${admin ? '' : 'Your company administrator chooses features.'}</p>`;
    const total = () => {
      const count = dialog.querySelectorAll('[name=features]:checked:not(:disabled)').length;
      dialog.querySelector('[data-feature-total]').textContent = `${count} selected · R${data.setupComplete ? count * data.extraFeatureFeeCents / 100 : 0}${data.setupComplete ? ' once-off test fee' : ' setup'}`;
    };
    dialog.querySelector('form').addEventListener('change', total);
    total();
  }
  document.addEventListener('click', async (event) => {
    if (!event.target.closest('[data-company-features]')) return;
    context = getContext();
    const expected = context;
    dialog.innerHTML = '<div class="dialog-heading"><h2>Company features</h2><button type="button" data-close-features>Close</button></div><p data-feature-status role="status">Loading features...</p>';
    dialog.showModal();
    try { await refreshUser(); await load(); }
    catch (error) {
      if (expected === getContext()) dialog.querySelector('[data-feature-status]').textContent = error.message || 'Connect to view features.';
    }
  });
  dialog.addEventListener('click', (event) => {
    if (event.target.closest('[data-close-features]')) dialog.close();
  });
  dialog.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (context !== getContext()) return;
    const expected = context;
    const button = event.target.querySelector('button');
    button.disabled = true;
    try {
      const features = [...dialog.querySelectorAll('[name=features]:checked:not(:disabled)')].map((item) => item.value);
      if (!features.length) throw new Error('Select at least one new feature.');
      await apiRequest('/api/company-features/requests', { method: 'POST', body: { features } });
      if (expected === getContext()) await load();
    } catch (error) {
      if (expected === getContext()) dialog.querySelector('[data-feature-status]').textContent = error.message || 'Could not request features.';
    } finally { button.disabled = false; }
  });
}
